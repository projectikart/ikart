#import qr1.py
#import readandwrite.py
import readandwrite.py
