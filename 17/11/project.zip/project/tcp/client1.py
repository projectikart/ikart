import socket
client=socket.socket()
ip=socket.gethostbyname(socket.gethostname())
print (ip)
client.connect((ip,1234))

while True:
    m=input("<data>")
    mes=m.encode('ascii')
    client.send(mes)
    r=client.recv(1024)
    print(str(r))
    if m=="lince":
        client.close()
        break;
