# QR code reader

QR code reader was implemented in Python for Raspberry Pi.

## Dependencies

* python 2.7
* fswebcam
* MySQLdb
* zbar-tools
* requests

## Hardware

* Raspberry Pi 3
* Webcam