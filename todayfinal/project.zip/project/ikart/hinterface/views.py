#from django.shortcuts import render
from django.http import HttpResponse
from .models import product
from django.template import loader


# Create your views here.
from django.shortcuts import render_to_response
from django.shortcuts import redirect
from django.template import RequestContext
from hinterface.models import *
from django.db.models import Sum
from hinterface.models import ikart_s101 as k
from django.views.decorators.csrf import csrf_exempt

def findkart(kartid):
    kart=ikart_s101()
    return kart
    pass

def additem(request):

    context = RequestContext(request)

    """fetching data from url"""
    prname = request.GET.get('key1', None)
    prprice = request.GET.get('key2', None)
    prid = request.GET.get('key3', None)
    kartid = request.GET.get('key4', None)

    """finding kart using kart id"""
    ikart = findkart(kartid)
    ikart.pid = prid
    ikart.name=prname
    ikart.price=prprice

    ikart.save()

    """uploading product to  database"""
    """ classname=kartid"""




    return HttpResponse("ok")

def receipt(request):
    print("\n\n\n\ndtesdfyedsysefg\n\n")


    return HttpResponse("<h1><marquee> {% {{ context }} This is Hinterface</h1>")
    # A HTTP POST?
    '''if request.method == 'POST':
        template=loader.get_template('hinterface/receipt.html')
        return HttpResponse(template.render(context,request))
        form = TaskItemForm(request.POST)


        # Have we been provided with a valid form?
        if form.is_valid():
            # Save the new category to the database.
            task = form.save(commit=False)
            task.usern = request.user
            task.save()


            # Redirect to home (/)
            return redirect('/')
        else:
            # The supplied form contained errors - just print them to the terminal.
            print ("form.errors")'''

"""****************************************************select * from any kart table *************************************************************"""
def callproducts(s):
    if s=='ikart_s101':
        allproduct =ikart_s101.objects.all()
        return allproduct
    pass

def index(request):
    """rows = ikart_s101.objects.filter()
    for r in rows:
        r.delete()"""
    kartid = request.GET.get('kartid', None)

    allproduct=callproducts(kartid)

    items = ikart_s101.objects.aggregate(Sum('price'))

    template=loader.get_template('hinterface/index.html')

    context ={
    'kart':allproduct,'price':items
    }

    return HttpResponse(template.render(context))


def detail(request):
    return HttpResponse("<h1><marquee> This is Hinterface</h1>")

def user(request):

    template=loader.get_template('hinterface/user.html')
    return HttpResponse(template.render())

def delete(request):
    rows = ikart_s101.objects.filter()
    for r in rows:
        r.delete()
    template=loader.get_template('hinterface/delete.html')
    return HttpResponse(template.render())
