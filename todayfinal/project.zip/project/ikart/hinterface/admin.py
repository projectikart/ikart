from django.contrib import admin

# Register your models here.
from .models import product
from .models import ikart_s101

admin.site.register(ikart_s101)
admin.site.register(product)
