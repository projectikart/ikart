import socket
server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ip=socket.gethostbyname(socket.gethostname())
print (ip)
port=1234
add=(ip,port)
server.bind(add)
server.listen(1)
def serve():

    print("Start")
    client,addr=server.accept()
    print ("Connected",add[0],add[1])
    while True:
        data=client.recv(1024)
        print ("recieved")
        m="received"
        client.send(m.encode('ascii'))
        decodeddata=str(data)
        print ("Data:",decodeddata)
        client.close()
        break

while True:
    serve()
