#from django.shortcuts import render
from django.http import HttpResponse
from .models import product
from django.template import loader


# Create your views here.
from django.shortcuts import render_to_response
from django.shortcuts import redirect
from django.template import RequestContext
from hinterface.models import product
from django.views.decorators.csrf import csrf_exempt

def additem(request):
    context = RequestContext(request)

    prname = request.GET.get('key1', None)
    prprice = request.GET.get('key2', None)
    prid = request.GET.get('key3', None)
    kartid = request.GET.get('key4', None)

    """ classname=kartid"""

    ikart_s101
    return HttpResponse("ok")

def receipt(request):
    print("\n\n\n\ndtesdfyedsysefg\n\n")


    return HttpResponse("<h1><marquee> {% {{ context }} This is Hinterface</h1>")
    # A HTTP POST?
    '''if request.method == 'POST':
        template=loader.get_template('hinterface/receipt.html')
        return HttpResponse(template.render(context,request))
        form = TaskItemForm(request.POST)


        # Have we been provided with a valid form?
        if form.is_valid():
            # Save the new category to the database.
            task = form.save(commit=False)
            task.usern = request.user
            task.save()


            # Redirect to home (/)
            return redirect('/')
        else:
            # The supplied form contained errors - just print them to the terminal.
            print ("form.errors")'''

def index(request):
    print("\n\n\n\ndtesdfyedsysefg\n\n")
    allproduct = product.objects.all()
    template=loader.get_template('hinterface/index.html')
    context ={
    'product':allproduct,
    }
    print(context)
    return HttpResponse(template.render(context,request))

def detail(request):
    return HttpResponse("<h1><marquee> This is Hinterface</h1>")
