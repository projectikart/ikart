from django.apps import AppConfig


class HinterfaceConfig(AppConfig):
    name = 'hinterface'
