from django.db import models

# Create your models here.
class product(models.Model):
    pid = models.CharField(max_length=250)
    name = models.CharField(max_length=250)
    price = models.CharField(max_length=250)

class ikart_s101(models.Model):
    pid = models.CharField(max_length=250)
    name = models.CharField(max_length=250)
    price = models.CharField(max_length=250)

    def __str__(self):
        return self.pid + "-" + self.name + self.price
