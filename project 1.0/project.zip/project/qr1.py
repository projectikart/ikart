
from qrtools import QR
myCode = QR(filename="/home/pi/Desktop/qw.jpeg")
if myCode.decode():
  print (myCode.data)
  print (myCode.data_type)
  print (myCode.data_to_string())
