
import os
import time
# do forever 
os.system('fswebcam -r 1024x786  --jpeg 50 qw.jpeg') # uses Fswebcam to take picture
