from qrtools import QR
import os
import time
# do forever
os.system('fswebcam -r 1024x786  --jpeg 50 qw.jpeg') # uses Fswebcam to take picture
time.sleep(5)


myCode = QR(filename="/home/pi/Desktop/project/qw.jpeg")
if myCode.decode():
  print (myCode.data)
  print (myCode.data_type)
  print (myCode.data_to_string())
